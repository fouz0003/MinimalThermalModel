# Thermal Energy Storage (TES) Simulation with Simscape

This project provides MATLAB scripts and Simulink/Simscape model placeholders for simulating a Thermal Energy Storage (TES) system, potentially coupled with a PV source and heat exchanger, based on the analysis of various research papers.

## Project Structure

```
Thermal-Energy-Storage/
  ├── ThermalEnergyStorageSimscape.prj_to_generate_with_matlab  (Placeholder - Create in MATLAB)
  ├── models/                                                  (Simulink models)
  │   ├── ResidentialBuildingTESandPVcell.slx_to_generate_with_matlab  (Placeholder - Create in Simulink)
  │   └── minimal_example/
  │         └── MinimalThermalModel.slx_to_generate_with_matlab         (Placeholder - Create in Simulink)
  ├── ScriptData/                                              (MATLAB scripts)
  │   ├── AdvancedThermalParams.m               (Parameters for full model)
  │   ├── MinimalThermalParams.m               (Parameters for minimal model)
  │   ├── runMinimalThermalSim.m               (Script to run minimal simulation)
  │   └── runResUnitHeatingSim.m               (Script to run full simulation)
  ├── Tests/                                                   (Unit tests)
  │     └── README.md                           (Placeholder for Test Directory)
  └── README.md                                                (This file)
```

## Thermal Energy Storage - Theory and Application

Thermal Energy Storage (TES) is a technology that stores thermal energy by heating or cooling a storage medium so that the stored energy can be used later for heating, cooling, or power generation applications.

### Key Thermal Energy Storage Principles:

1. **Basic Heat Transfer Equation**: 
   ```
   Q = m × cp × ΔT
   ```
   Where:
   - Q = Heat energy transferred [J]
   - m = Mass of storage material [kg]
   - cp = Specific heat capacity [J/kg·K]
   - ΔT = Temperature change [K]

   **IMPORTANT**: This equation represents the fundamental relationship between energy and temperature change in a material. The energy stored (Q) is directly proportional to the mass (m), specific heat capacity (cp), and temperature difference (ΔT).

2. **Temperature Rise Rate**: 
   For a constant power (P) input:
   ```
   Rate of temperature rise = P / (m × cp) [K/s]
   ```
   
   **IMPORTANT**: This equation shows how quickly temperature rises when applying constant power. The larger the thermal capacity (m × cp), the slower the temperature rises for a given power input.

3. **Final Temperature Calculation**:
   For a constant power input over time (t):
   ```
   Tfinal = Tinitial + (P × t) / (m × cp)
   ```
   
   **IMPORTANT**: This equation allows you to predict the final temperature after applying heat for a specific time period. In our simulation, we will compare this theoretical value with the simulated result.

## Getting Started: Building the Minimal Thermal Model (Step-by-Step)

This section provides detailed instructions for creating the minimal thermal model from scratch.

### Prerequisites
- MATLAB R2020a or newer
- Simulink
- Simscape add-on

### Part 1: Creating the Minimal Thermal Model

1. **Open MATLAB and Navigate to Project Directory**
   - Launch MATLAB
   - Navigate to the `Thermal-Energy-Storage` directory
   - Create the project file if you haven't already (as described in the original instructions)

2. **Create a New Simulink Model**
   - In MATLAB, navigate to the `models/minimal_example/` directory
   - Click on `File` → `New` → `Model` to create a new Simulink model
   - Save it as `MinimalThermalModel.slx` in the `models/minimal_example/` directory

3. **Add Required Simscape Blocks**
   - Open the Simulink Library Browser by clicking the Library Browser icon or pressing Ctrl+Shift+L
   - Navigate to `Simscape` → `Foundation Library` → `Thermal` section

4. **Add and Configure the Thermal Mass Block**
   - Find and add `Thermal Elements` → `Thermal Mass` to your model
   - Position it in the center of your model
   - Double-click on the block to open its parameters
   - Name this block exactly as `Thermal Mass` (important for the script)
   - The parameters will be set by the simulation script later
   
   **IMPORTANT NOTE**: The Thermal Mass block represents our thermal energy storage material. It has two key parameters:
   - Thermal Mass (m × cp): This is the product of mass and specific heat capacity [J/K]
   - Initial Temperature: The starting temperature of the material [K]

5. **Add and Configure the Heat Source**
   - Find and add `Thermal Sources` → `Controlled Heat Flow Rate Source` to your model
   - Position it to the left of the Thermal Mass block
   - Name this block exactly as `Heat Source` (important for the script)
   - The power value will be set by the simulation script later
   
   **IMPORTANT NOTE**: The Heat Source block provides constant power input to the thermal mass. This represents electrical heating (like from a PV panel) or any other heat source.

6. **Add a Thermal Reference**
   - Find and add `Thermal Elements` → `Thermal Reference` to your model
   - Position it below the Heat Source block
   
   **IMPORTANT NOTE**: The Thermal Reference block establishes a reference temperature (similar to ground in electrical circuits). All temperature measurements are relative to this reference.

7. **Add a Solver Configuration**
   - Navigate to `Simscape` → `Utilities` and add `Solver Configuration` to your model
   - Position it anywhere in your model
   - Keep the default parameters
   
   **IMPORTANT NOTE**: The Solver Configuration block is essential for any Simscape model to work. It contains the physical system's numerical integration settings.

8. **Connect the Blocks**
   - Connect the positive port (+) of the `Heat Source` block to the left port of the `Thermal Mass` block
   - Connect the negative port (-) of the `Heat Source` block to the `Thermal Reference` block
   - Connect the `Solver Configuration` block to the circuit by right-clicking and selecting "Connect to Simscape Circuit"
   
   **IMPORTANT NOTE**: 
   - The connections represent heat flow paths. Heat flows from the Heat Source, through the Thermal Mass, and to the reference.
   - The positive port of the Heat Source outputs heat to the Thermal Mass.
   - The negative port of the Heat Source needs a return path through the Thermal Reference.
   
   Your model should look something like this:
   ```
   +-------------+         +---------------+
   |             |         |               |
   | Heat Source +-------->+ Thermal Mass  |
   |      +      |         |               |
   +------+------+         +---------------+
          |
          |
          v
   +-------------+         +-------------------+
   |  Thermal    |         | Solver            |
   |  Reference  |         | Configuration     |
   +-------------+         +-------------------+
   ```

9. **Enable Temperature Logging**
   - Right-click on the port (connection point) of the `Thermal Mass` block where the heat flow connects
   - Select `Properties` from the context menu
   - Go to the `Logging` tab
   - Check `Log simulation data`
   - In the "Conserving port" section, ensure temperature (T) is selected
   - Set the `Logging name` to exactly `MinimalTemperature` (important for the script)
   - Click `OK` to close the dialog
   
   **IMPORTANT NOTE**: Signal logging is crucial for analyzing results. The script looks for a signal named `MinimalTemperature` to plot the temperature evolution over time.

10. **Save the Model**
    - Save your model one more time using `File` → `Save`
    - Verify it is saved as `MinimalThermalModel.slx` in the `models/minimal_example/` directory
    - You can now delete the placeholder file `MinimalThermalModel.slx_to_generate_with_matlab` if it exists

### Part 2: Running the Minimal Thermal Simulation

1. **Open the Simulation Script**
   - In MATLAB, navigate to the `ScriptData` folder
   - Open `runMinimalThermalSim.m` to review it (optional)

2. **Review Simulation Parameters (Optional)**
   - Open `MinimalThermalParams.m` to see the parameters used in the simulation:
     - Mass: 10 kg
     - Specific heat: 900 J/kg·K (similar to aluminum)
     - Initial temperature: 25°C (converted to K in the file)
     - Heat input: 50 W (constant)
   
   **IMPORTANT NOTE**: These parameters determine how quickly the thermal mass heats up. The thermal capacity (m × cp) is 9000 J/K, which means it takes 9000 Joules to raise the temperature by 1 Kelvin.

3. **Run the Simulation**
   - Run `runMinimalThermalSim.m` script by clicking the Run button or typing `runMinimalThermalSim` in the MATLAB Command Window
   - The script will:
     - Load the parameters
     - Configure the Simulink model with these parameters
     - Run a 1-hour simulation
     - Plot the temperature evolution
     - Compare the simulated final temperature with the theoretical calculation
   
   **IMPORTANT NOTE**: If you get errors, check:
   - The model file exists at the correct location
   - Block names match exactly what the script expects ("Thermal Mass" and "Heat Source")
   - The temperature signal is logged with name "MinimalTemperature"

4. **Analyze the Results**
   - Examine the temperature plot showing the linear temperature rise
   - Note the theoretical temperature rise rate displayed in the MATLAB Command Window
   - Compare the simulated final temperature with the theoretical calculation
   - Observe how closely they match (they should be very close in this simplified model)
   
   **IMPORTANT NOTE**: In this minimal model without heat loss, the temperature should rise linearly. The script calculates both simulated and theoretical values to verify that your model is working correctly.

### Part 3: Expected Results and Learning Outcomes

**Expected Results:**
- The temperature should increase linearly from 25°C
- For 50 W power input to a 10 kg mass with specific heat of 900 J/kg·K over 1 hour:
  - The thermal capacity is 9000 J/K
  - Temperature rise rate should be approximately 0.33°C per minute
  - Final temperature should be about 45°C (20°C increase)

**Theoretical Calculations:**
1. Thermal capacity = mass × specific heat = 10 kg × 900 J/kg·K = 9,000 J/K
2. Temperature rise rate = power / thermal capacity = 50 W / 9,000 J/K = 0.0056 K/s = 0.33°C/min
3. Total temperature rise = rate × time = 0.33°C/min × 60 min = 20°C
4. Final temperature = initial + rise = 25°C + 20°C = 45°C

**IMPORTANT**: Understanding these calculations is critical for thermal systems. You should be able to predict temperature behavior using these formulas and verify your predictions with the simulation.

**Learning Outcomes:**
- Understanding the relationship between heat input, thermal mass, and temperature change
- Visualizing how temperature evolves in a simple thermal storage system
- Learning how to implement thermal simulations in Simulink/Simscape
- Comparing theoretical calculations with simulation results
- Developing skills to create more complex thermal models

### Part 4: Exercises and Extensions

Try these exercises to deepen your understanding:

1. **Parameter Variation:**
   - Modify `MinimalThermalParams.m` to double the mass or specific heat
   - Run the simulation again and observe how the temperature rise rate changes
   - Calculate the expected new temperature rise and compare with simulation
   
   **HINT**: Doubling the mass will halve the temperature rise rate.

2. **Material Comparison:**
   - Change the specific heat to model different materials:
     - Water: ~4200 J/kg·K
     - Copper: ~385 J/kg·K
     - Concrete: ~880 J/kg·K
   - Compare how different materials store thermal energy
   
   **HINT**: Materials with higher specific heat can store more thermal energy per unit mass for the same temperature change.

3. **Add Heat Loss:**
   - For more advanced students, modify the model to include heat loss to the environment
   - Add a `Thermal Conductor` block between the Thermal Mass and Thermal Reference
   - Set an appropriate thermal conductance value
   - Observe how the temperature curve changes from linear to exponential
   
   **HINT**: With heat loss, the temperature will rise more slowly and eventually reach equilibrium when heat input equals heat loss.

4. **Variable Power Input:**
   - Replace the constant heat source with a variable one
   - Use a Simulink signal to control the heat flow (e.g., sinusoidal pattern)
   - Observe how the temperature responds to variable input
   
   **HINT**: You'll need to add a Simulink-PS converter block to convert a Simulink signal to a physical signal.

## Creating the Full Residential Building Simulation Model

Follow these detailed steps to create the more complex residential building TES model:

1. **Create a New Simulink Model**
   - Navigate to the `models` directory
   - Create a new Simulink model and save it as `ResidentialBuildingTESandPVcell.slx`

2. **Organize Your Model with Subsystems**
   - Create these subsystems by right-clicking in the model and selecting "Add" → "Subsystem":
     - `Sand_TES` (for the thermal energy storage)
     - `PV_to_TES` (for the PV heat source)
     - `Heat_Exchanger` (for heat exchange between TES and building)
     - `Fluid_Loop` (optional, for fluid circulation)
     - `Building_Load` (optional, for building thermal load)

3. **Create the TES Subsystem**
   - Inside the `Sand_TES` subsystem, add a `Thermal Mass` block
   - Name it exactly "Thermal Mass" (for script compatibility)
   - Add a port for heat input and a port for heat extraction

4. **Create the PV Heat Source**
   - Inside the `PV_to_TES` subsystem, add a `Controlled Heat Flow Rate Source` block
   - Name it exactly "Heat Flow Rate Source" (for script compatibility)
   - This represents heat generated from the PV system

5. **Create the Heat Exchanger**
   - Inside the `Heat_Exchanger` subsystem, add a `Thermal Conductor` block
   - Name it exactly "Thermal Conductor" (for script compatibility)
   - This models heat transfer between the TES and the building/fluid

6. **Add Required References and Configuration**
   - Add a `Thermal Reference` block at the top level of your model
   - Add a `Solver Configuration` block and connect it to the system

7. **Connect the Subsystems**
   - Connect the output of `PV_to_TES` to the input of `Sand_TES`
   - Connect `Sand_TES` to `Heat_Exchanger`
   - Connect all negative ports to the `Thermal Reference`

8. **Enable Temperature Logging**
   - Right-click on the thermal port of the `Thermal Mass` block
   - Enable logging and name the signal `StorageTemperature`

9. **Save Your Model**
   - Save the model in the `models` directory
   - Ensure all block names match exactly what's expected in the script

## Running the Full Residential Building Simulation

Once you understand the minimal model, proceed to the more complex residential building simulation:

1. **Review the Advanced Parameters**
   - Open `AdvancedThermalParams.m` to understand the parameters for the full system
   - Note the increased scale and complexity compared to the minimal model

2. **Run the Full Simulation**:
   - Navigate to the `ScriptData` folder
   - Run `runResUnitHeatingSim.m` to simulate the complete system with PV, TES, and heat exchanger
   - The script will load parameters, configure the model, run a 24-hour simulation, and plot results

3. **Analyze the Results**
   - Observe how the TES temperature changes over a 24-hour period
   - Note any cyclical patterns related to the heating/cooling cycle
   - Consider how the system's performance could be optimized

## Troubleshooting Common Issues

If you encounter problems, check these common issues:

1. **Model Not Found Error**
   - Ensure your model files are saved with the exact names expected by the scripts
   - Check that the paths in the script match your folder structure

2. **Block Configuration Error**
   - Verify that your block names match exactly what the script expects
   - Check for typos in block names ("Thermal Mass" not "ThermalMass")

3. **Logging Issues**
   - Make sure signal logging is enabled for the temperature signals
   - Verify the logging names match what the script looks for (e.g., "MinimalTemperature")

4. **Simulation Errors**
   - Check that all blocks are properly connected
   - Ensure the Solver Configuration block is connected to the circuit
   - Verify parameter values are reasonable (no extreme values)

5. **No Plot Generated**
   - Check the MATLAB Command Window for warnings or errors
   - Verify that signal logging is correctly enabled

## Important Notes

*   **Block Paths:** If you change the names or hierarchy of the blocks within your `.slx` models, you **must** update the corresponding block paths in the `set_param` commands within the `runMinimalThermalSim.m` and `runResUnitHeatingSim.m` scripts.
*   **Parameter Files:** Modify the `.m` files in `ScriptData` to change simulation parameters (TES properties, heat source power, HX characteristics, etc.).
*   **Signal Logging:** Ensure signal logging is correctly configured in the Simulink models for the signals you wish to analyze or plot via the scripts.

## Testing

The `Tests/` directory is provided for MATLAB Unit Tests. You can create test scripts here (e.g., using `classdef YourTest < matlab.unittest.TestCase`) to verify the behavior of your models and scripts under different conditions.

## Code Documentation

This project houses MATLAB simulation scripts in the `ScriptData` directory:

- `runMinimalThermalSim.m`: Runs the minimal thermal simulation using parameters defined in `MinimalThermalParams.m`.
- `runResUnitHeatingSim.m`: Runs the comprehensive Residential Building TES simulation using parameters from `AdvancedThermalParams.m`.

**Important:** The placeholder files with suffix `_to_generate_with_matlab` (for example, `ThermalEnergyStorageSimscape.prj_to_generate_with_matlab`, `MinimalThermalModel.slx_to_generate_with_matlab`, and `ResidentialBuildingTESandPVcell.slx_to_generate_with_matlab`) must be replaced with fully functional Simulink/Simscape models as described in the documentation.

Ensure that the models have proper signal logging (e.g., logging names such as `MinimalTemperature` and `StorageTemperature`) as referenced in the simulation scripts for correct data analysis. 