# This directory is intended for MATLAB unit test files.
# Create scripts here (e.g., using the Test Browser or by creating subclasses of matlab.unittest.TestCase)
# to verify the functionality of your models and scripts. 